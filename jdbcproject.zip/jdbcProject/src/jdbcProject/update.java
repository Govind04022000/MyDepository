package jdbcProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.util.Scanner;

public class update {
	public static void updatedemo() throws Exception {
		PreparedStatement ps;
		Connection cc;
		Class.forName("com.mysql.jdbc.Driver");
		cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		Scanner sc=new Scanner(System.in);
		System.out.println("id,name,marks,grade which entity you have to update");
		System.out.println("for id enter 1\nfor marks enter 2\nfor marks enter 3\nfor grade enter 4");
		int entity=sc.nextInt();
		switch(entity) {
		case 1:
			ps=cc.prepareStatement("update studentinfo set id=? where id=?");
			System.out.println();
			System.out.println("enter old id from given id's");
			retrive.retriveid();
			System.out.println();
			int oldid=sc.nextInt();
			System.out.println("enter new id");
			int newid=sc.nextInt();
			ps.setInt(1, newid);
			ps.setInt(2, oldid);
			ps.execute();
			break;
		case 2:
			ps=cc.prepareStatement("update studentinfo set name=? where name=?");
			System.out.println();
			System.out.println("enter old name from given name's");
			retrive.retrivename();
			System.out.println();
			String oldname=sc.next();
			System.out.println("enter new name");
			String newname=sc.next();
			ps.setString(1, newname);
			ps.setString(2, oldname);
			ps.execute();
			break;
		case 3:
			ps=cc.prepareStatement("update studentinfo set marks=? where marks=?");
			System.out.println();
			System.out.println("enter old id from given mark's");
			retrive.retrivemarks();
			System.out.println();
			int oldmarks=sc.nextInt();
			System.out.println("enter new id");
			int newmarks=sc.nextInt();
			ps.setInt(1, newmarks);
			ps.setInt(2, oldmarks);
			ps.execute();
			break;
		case 4:
			ps=cc.prepareStatement("update studentinfo set grade=? where grade=?");
			System.out.println();
			System.out.println("enter old name from given grade's");
			retrive.retrivegrade();
			System.out.println();
			String oldgrade=sc.next();
			System.out.println("enter new name");
			String newgrade=sc.next();
			ps.setString(1, newgrade);
			ps.setString(2, oldgrade);
			ps.execute();
			break;
		default:
			System.out.println("sorry but you have entered the wrong value");
			break;
		}
		System.out.println("updated record");
		retrive.retrivedemo();
	}
}
