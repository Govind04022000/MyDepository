package jdbcProject;
import java.util.Scanner;

public class Demomain {

	public static void main(String[] args) throws Exception {
		Scanner sc=new Scanner(System.in);
		System.out.println("which operation you have to perform");
		System.out.println("enter 1:for insert\nenter 2:for update\nenter 3:for delete\nenter 4:for retrive ");
		int operation =sc.nextInt();
		switch(operation) {
			case 1:
				insert.insertdemo();
				break;
			case 2:
				update.updatedemo();
				break;
			case 3:
				delete.deletedemo();
				break;
			case 4:
				retrive.retrivedemo();
				break;
			default:
				System.out.println("you have enter the wrong input");
				break;
		}
	}

}
