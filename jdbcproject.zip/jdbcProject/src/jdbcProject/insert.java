package jdbcProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Scanner;

public class insert {
	
	
	static int id;

	public static void insertdemo() throws Exception {
		ResultSet rs;
		Scanner sc=new Scanner(System.in);
		System.out.println("how many entities you have to add");
		int looprun=sc.nextInt();
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("insert into studentinfo values(?,?,?,?)");
		for(int i=1;i<=looprun;i++) {
			
			System.out.println("enter 1st id\n2nd name\n3rd marks\n4th grade");
			id=sc.nextInt();
			
			String name=sc.next();
			int marks=sc.nextInt();
			String grade=sc.next();
			ps.setInt(1, id);
			ps.setString(2, name);
			ps.setInt(3, marks);
			ps.setString(4, grade);
			ps.execute();
			System.out.println("rocord inserted");
		}
		retrive.retriveidrecord(id);

	}

}
