package jdbcProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class retrive {
	public static void retrivedemo() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("select * from studentinfo");
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4));
		}	
	}
	public static void retriveid() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("select id from studentinfo");
		ResultSet rs=ps.executeQuery();
		System.out.println("id's in the database");
		while(rs.next()) {
			System.out.print(rs.getInt(1)+" ");
		}	
	}
	
	public static void retrivename() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("select name from studentinfo");
		ResultSet rs=ps.executeQuery();
		System.out.println("name's in the database");
		while(rs.next()) {
			System.out.print(rs.getString(1)+" ");
		}	
	}
	public static void retrivemarks() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("select marks from studentinfo");
		ResultSet rs=ps.executeQuery();
		System.out.println("marks in the database");
		while(rs.next()) {
			System.out.print(rs.getInt(1)+" ");
		}	
	}
	public static void retrivegrade() throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("select grade from studentinfo");
		ResultSet rs=ps.executeQuery();
		System.out.println("grade's in the database");
		while(rs.next()) {
			System.out.print(rs.getString(1)+" ");
		}	
	}
	public static void retriveidrecord(int id1) throws Exception {
		Class.forName("com.mysql.jdbc.Driver");
		Connection cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		PreparedStatement ps=cc.prepareStatement("select * from studentinfo where id =?");
		ps.setInt(1, id1);
		ResultSet rs=ps.executeQuery();
		while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getInt(3)+" "+rs.getString(4));
		}	
		
	}
}
