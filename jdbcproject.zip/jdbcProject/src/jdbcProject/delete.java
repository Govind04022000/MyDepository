package jdbcProject;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class delete {
	public static void deletedemo() throws Exception {
		Connection cc;
		PreparedStatement ps;
		java.util.Scanner sc=new java.util.Scanner(System.in);
		Class.forName("com.mysql.jdbc.Driver");
		cc=DriverManager.getConnection("jdbc:mysql://localhost:3306/jdbcproject", "root", "root");
		System.out.println("id,name,marks,grade from which entity you have to delete the record");
		System.out.println("for id enter 1\nfor marks enter 2\nfor marks enter 3\nfor grade enter 4");
		int entity=sc.nextInt();
	switch(entity) {
	case 1:
		ps=cc.prepareStatement("delete from studentinfo where id=?");
		System.out.println("enter id");
		int id=sc.nextInt();
		ps.setInt(1, id);
		ps.execute();
		break;
	case 2:
		ps=cc.prepareStatement("delete from studentinfo where name=?");
		System.out.println("enter name");
		String name=sc.next();
		ps.setString(1, name);
		ps.execute();
		break;
	case 3:
		ps=cc.prepareStatement("delete from studentinfo where marks=?");
		System.out.println("enter marks");
		int marks=sc.nextInt();
		ps.setInt(1, marks);
		ps.execute();
		break;
	case 4:
		ps=cc.prepareStatement("delete from studentinfo where grade=?");
		System.out.println("enter grade");
		String grade=sc.next();
		ps.setString(1, grade);
		ps.execute();
		break;
	default:
		System.out.println("sorry but you have entered the wrong value");
		break;
	}
	System.out.println("record deleted");
	retrive.retrivedemo();
	}
}
